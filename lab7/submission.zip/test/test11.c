void f() {
  int i;
  int sum = 0;
  for (i = 0; i < 10; i++) {
    sum += 1;
  }
  int z = i / sum;
}
