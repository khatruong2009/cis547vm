#include <stdio.h>

int main() {
  int x = getchar();
  int y = 5 / x;
  return 0;
}
